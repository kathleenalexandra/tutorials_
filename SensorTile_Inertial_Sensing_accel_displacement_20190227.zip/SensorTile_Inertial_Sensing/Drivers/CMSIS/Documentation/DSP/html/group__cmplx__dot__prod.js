var group__cmplx__dot__prod =
[
    [ "arm_cmplx_dot_prod_f32", "group__cmplx__dot__prod.html#gadcfaf567a25eb641da4043eafb9bb076", null ],
    [ "arm_cmplx_dot_prod_q15", "group__cmplx__dot__prod.html#ga2b08b5e8001d2c15204639d00893fc70", null ],
    [ "arm_cmplx_dot_prod_q31", "group__cmplx__dot__prod.html#ga5b731a59db062a9ad84562ef68a6c8af", null ]
];