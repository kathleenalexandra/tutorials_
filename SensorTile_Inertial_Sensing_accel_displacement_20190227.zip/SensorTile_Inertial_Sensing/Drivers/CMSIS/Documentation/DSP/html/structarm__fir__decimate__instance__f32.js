var structarm__fir__decimate__instance__f32 =
[
    [ "M", "structarm__fir__decimate__instance__f32.html#a76a8b2161731638eb3d67f277919f95d", null ],
    [ "numTaps", "structarm__fir__decimate__instance__f32.html#a2aa2986129db8affef03ede88dd45a03", null ],
    [ "pCoeffs", "structarm__fir__decimate__instance__f32.html#a268a8b0e80a3d9764baf33e4bc10dde2", null ],
    [ "pState", "structarm__fir__decimate__instance__f32.html#a5bddf29aaaf2011d2e3bcec59a83f633", null ]
];