var structarm__fir__decimate__instance__q15 =
[
    [ "M", "structarm__fir__decimate__instance__q15.html#aad9320284218b3aa378527ea518cf093", null ],
    [ "numTaps", "structarm__fir__decimate__instance__q15.html#ac1e9844488ec717da334fbd4c4f41990", null ],
    [ "pCoeffs", "structarm__fir__decimate__instance__q15.html#a01cacab67e73945e8289075598ede14d", null ],
    [ "pState", "structarm__fir__decimate__instance__q15.html#a3f7b5184bb28853ef401b001df121047", null ]
];