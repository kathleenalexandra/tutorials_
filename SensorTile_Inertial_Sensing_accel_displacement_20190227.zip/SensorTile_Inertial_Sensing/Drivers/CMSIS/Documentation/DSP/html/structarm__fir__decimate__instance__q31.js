var structarm__fir__decimate__instance__q31 =
[
    [ "M", "structarm__fir__decimate__instance__q31.html#ad3d6936c36303b30dd38f1eddf248ae5", null ],
    [ "numTaps", "structarm__fir__decimate__instance__q31.html#a37915d42b0dc5e3057ebe83110798482", null ],
    [ "pCoeffs", "structarm__fir__decimate__instance__q31.html#a030d0391538c2481c5b348fd09a952ff", null ],
    [ "pState", "structarm__fir__decimate__instance__q31.html#a0ef0ef9e265f7ab873cfc6daa7593fdb", null ]
];