var structarm__fir__instance__q7 =
[
    [ "numTaps", "structarm__fir__instance__q7.html#a9b50840e2c5ef5b17e1a584fb4cf0d06", null ],
    [ "pCoeffs", "structarm__fir__instance__q7.html#a0e45aedefc3fffad6cb315c5b6e5bd49", null ],
    [ "pState", "structarm__fir__instance__q7.html#aaddea3b9c7e16ddfd9428b7bf9f9c200", null ]
];